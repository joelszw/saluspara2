export const servicedata = [
    {
        id: 1,
        icon: "fa-solid fa-file",
        title: "Content Marketing",
        content: "Rhoncus magna curabitur pretium non arcu magnis vestibulum cursus. Maximus gravida orci libero tristique non",
        link: "#",
    },
    {
        id: 2,
        icon: "fa-solid fa-file",
        title: "On-Page SEO",
        content: "Rhoncus magna curabitur pretium non arcu magnis vestibulum cursus. Maximus gravida orci libero tristique non",
        link: "#",
    },
    {
        id: 3,
        icon: "fa-solid fa-magnifying-glass",
        title: "Off-Page SEO",
        content: "Rhoncus magna curabitur pretium non arcu magnis vestibulum cursus. Maximus gravida orci libero tristique non",
        link: "#",
    },
    {
        id: 4,
        icon: "fa-solid fa-share-nodes",
        title: "Social Media Marketing",
        content: "Rhoncus magna curabitur pretium non arcu magnis vestibulum cursus. Maximus gravida orci libero tristique non",
        link: "#",
    },
    {
        id: 5,
        icon: "fa-solid fa-address-card",
        title: "Analytic Reporting",
        content: "Rhoncus magna curabitur pretium non arcu magnis vestibulum cursus. Maximus gravida orci libero tristique non",
        link: "#",
    },
    {
        id: 6,
        icon: "fa-solid fa-people-group",
        title: "Influencer Marketing",
        content: "Rhoncus magna curabitur pretium non arcu magnis vestibulum cursus. Maximus gravida orci libero tristique non",
        link: "#",
    },
];
export const teamdata = [
    {
        id: 1,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Jhon Doe",
        designation: "Ceo & Founder",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 2,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Sarah Jane",
        designation: "Marketing",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 3,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Marry Adams",
        designation: "Designer",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 4,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Peter Willson",
        designation: "Co-Founder",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 5,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Jessica Gillbert",
        designation: "Bussiness Manager",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 6,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "William",
        designation: "Bussiness Manager",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 7,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Katy Wayne",
        designation: "Marketing",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
    {
        id: 8,
        image: "/assets/images/dummy-img-600x600.jpg",
        name: "Bruce Parker",
        designation: "Co-Founder",
        linkedin: "https://www.linkedin.com/",
        twitter: "https://x.com/",
        behance: "https://www.behance.net/"
    },
];
export const testimonialdata = [
    {
        id: 1,
        image: "/assets/images/dummy-img-400x400.jpg",
        name: "Jhon Doe",
        designation: "Client",
        content: "Pellentesque primis litora malesuada, torquent venenatis commodo. Egestas taciti in posuere, pellentesque nunc nostra ornare penatibus. Fringilla facilisis parturient sit dignissim phasellus cras magnis.",
        speed: "animated-fast",
        size: "wide"
    },
    {
        id: 2,
        image: "/assets/images/dummy-img-400x400.jpg",
        name: "Sarah Smith",
        designation: "Client",
        content: "Pellentesque primis litora malesuada, torquent venenatis commodo. Egestas taciti in posuere, pellentesque nunc nostra ornare penatibus. Fringilla facilisis parturient sit dignissim phasellus cras magnis.",
        speed: "",
        size: "small"
    },
    {
        id: 3,
        image: "/assets/images/dummy-img-400x400.jpg",
        name: "Peter Walk",
        designation: "Client",
        content: "Pellentesque primis litora malesuada, torquent venenatis commodo. Egestas taciti in posuere, pellentesque nunc nostra ornare penatibus. Fringilla facilisis parturient sit dignissim phasellus cras magnis.",
        speed: "animated-slow",
        size: "small"
    },
    {
        id: 4,
        image: "/assets/images/dummy-img-400x400.jpg",
        name: "Joe Bloggs",
        designation: "Client",
        content: "Pellentesque primis litora malesuada, torquent venenatis commodo. Egestas taciti in posuere, pellentesque nunc nostra ornare penatibus. Fringilla facilisis parturient sit dignissim phasellus cras magnis.",
        speed: "animated-fast",
        size: "wide"
    },
    {
        id: 5,
        image: "/assets/images/dummy-img-400x400.jpg",
        name: "David Willson",
        designation: "Client",
        content: "Pellentesque primis litora malesuada, torquent venenatis commodo. Egestas taciti in posuere, pellentesque nunc nostra ornare penatibus. Fringilla facilisis parturient sit dignissim phasellus cras magnis.",
        speed: "",
        size: "wide"
    },
    {
        id: 6,
        image: "/assets/images/dummy-img-400x400.jpg",
        name: "Marry Adams",
        designation: "Client",
        content: "Pellentesque primis litora malesuada, torquent venenatis commodo. Egestas taciti in posuere, pellentesque nunc nostra ornare penatibus. Fringilla facilisis parturient sit dignissim phasellus cras magnis.",
        speed: "animated-slow",
        size: "small"
    },
];
export const partnershipdata = [
    {
        id: 1,
        logo: "/assets/images/partner-4-65f90f1a4e273.webp"
    },
    {
        id: 2,
        logo: "/assets/images/partner-5-65f90f1ae5cd3.webp"
    },
    {
        id: 3,
        logo: "/assets/images/partner-6-65f90f1b3c463.webp"
    },
    {
        id: 4,
        logo: "/assets/images/partner-7-65f90f1bc7da0.webp"
    },
    {
        id: 5,
        logo: "/assets/images/partner-8-65f90f1847992.webp"
    },
    {
        id: 6,
        logo: "/assets/images/partner-9-65f90f351af88.webp"
    },
    {
        id: 7,
        logo: "/assets/images/partner-10-65f90f3519911.webp"
    },
];
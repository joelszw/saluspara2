export const BannerTag = [
    {
        id: 1,
        title: "On-Page SEO",
    },
    {
        id: 2,
        title: "Digital Marketing",
    },
    {
        id: 3,
        title: "Off-Page SEO",
    },
    {
        id: 4,
        title: "Social Media Marketing",
    },
    {
        id: 5,
        title: "Analytic and Reporting",
    },
    {
        id: 6,
        title: "Influencer Marketing",
    },
];
import React from "react";
import PageNotFoundSection from "../../Components/NotFound";

const PageNotFound = () => {
    return(
        <>
            <PageNotFoundSection />
        </>
    );
}

export default PageNotFound;